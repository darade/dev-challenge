/**
 *  Simple pull observer pattern for change notification.
 */
function Currency() {
    const observers = [];
    /**
    */
    return {
        add: function(item) {
            observers.push(item);
        },
        removeAll: function() {
            observers.length = 0;
        },
        notifyObservers(json, add) {
            observers.forEach(elem => {
                elem.notify(json, add);
            });
        }
    };
}
