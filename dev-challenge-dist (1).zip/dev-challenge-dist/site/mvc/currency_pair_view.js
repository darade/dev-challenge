/**
 *
 */
function CurrencyPairView(model) {
  /**
  */
    const DOM = {
        table: document.getElementById("tbody")
    }
    /**
    */
    function clearTable() {
        view.getDOM().table.innerHTML = "";
    }
    /**
    */
    function createRowWithJson(json) {
        var td = "";
        td += '<td>' + json.name + '</td>';
        td += '<td>' + json.bestAsk + '</td>';
        td += '<td>' + json.bestBid + '</td>';
        td += '<td>' + json.lastChangeAsk + '</td>';
        td += '<td>' + json.lastChangeBid + '</td>';
        td += '<td>' + json.openAsk + '</td>';
        td += '<td>' + json.openBid + '</td>';
        td += '<td> <span id="' + json.name + '"></span></td>';
        return td;
    }
    /**
    */
    function drawTable(json, add, recursive) {
        if (add && recursive) {
          var tr = document.createElement('tr');
          tr.innerHTML = createRowWithJson(json)
          view.getDOM().table.appendChild(tr);
          sparkline = document.getElementById(json['name'])
          Sparkline.draw(sparkline, json['sparkline']);
        } else {
            // update row
            clearTable();
            var list = model.getList();
            list.sort(model.sort_by('lastChangeBid', true, parseFloat));
            for (item in list) {
                drawTable(list[item], true , true)
            }
        }
    }
    /**
    */
    function getData() {
        // presentation logic
        return model.getList();
    }
    return {
        getDOM: function() {
            return DOM;
        },
        notify: function(json, add) {
            drawTable(json, add, false);
        }
    };
}
