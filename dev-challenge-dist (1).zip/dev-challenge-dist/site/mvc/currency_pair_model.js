/**
 *
 */
function CurrencyPairModel() {
    const currency = Currency(),
        list = [];
    return {
      /**
      */
        getList: function() {
            return list;
        },
        /**
        */
        deepEqual: function(x, y) {
            if ((typeof x == "object" && x != null) && (typeof y == "object" && y != null)) {
                if (Object.keys(x).length != Object.keys(y).length)
                    return false;
                for (var prop in x) {
                    if (y.hasOwnProperty(prop)) {
                        if (!deepEqual(x[prop], y[prop]))
                            return false;
                    } else
                        return false;
                }
                return true;
            } else if (x !== y)
                return false;
            else
                return true;
        },
        /**
        */
        sort_by: function(field, reverse, primer) {
            var key = primer ?
                function(x) {
                    return primer(x[field])
                } :
                function(x) {
                    return x[field]
                };
            reverse = !reverse ? 1 : -1;
            return function(a, b) {
                return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
            }
        },
        /**
        */
        sort: function(list) { // Not used any more
            var keys = Object.keys(list)
            var swapped;
            do {
                swapped = false;
                for (var i = 0; i < keys.length - 1; i++) {
                    if (list[keys[i]].lastChangeBid < list[keys[i + 1]].lastChangeBid) {
                        var temp = list[keys[i]];
                        list[keys[i]] = list[keys[i + 1]];

                        list[keys[i + 1]] = temp;

                        swapped = true;
                    }
                }
            } while (swapped);
            return list;
        },
        /**
        */
        getAndDeleteIfExist: function(item, list) {
            for (var i in list) {
                if (list[i]['name'] == item['name']) {
                    var json = list[i];
                    delete list[i];
                    return json;
                }
            }
            return null;
        },
        /**
        */
        updateMidPrice: function(json){
          var sparklineData = [];
          var midPrice=(json.bestBid+json.bestAsk)/2;
          if(json.sparklineData){
            sparklineData=json.sparklineData;
          }else{
            json.sparklineData=[];
          }
          var data={};
          data.midPrice=midPrice;
          data.ct=new Date().getTime();
          sparklineData.push(data);
          json.sparklineData=sparklineData;

          if(json.sparkline){
            json.sparkline=[];
            var newSparklineData = [];
            for(var i in json.sparklineData){
              var sp=json.sparklineData[i];
              if(sp.ct>(new Date().getTime()-30*60)){
                json.sparkline.push(sp.midPrice);
                newSparklineData.push(sp);
              }
            }
            json.sparklineData = newSparklineData;
          }else{
            json.sparkline=[];
            json.sparkline.push(midPrice);
          }
          return json;
        },
        /**
        */
        add: function(item) {
            json = JSON.parse(item.trim());
            var add = true;
            var existingItem = model.getAndDeleteIfExist(json, list);
            if (existingItem != null) {
                // update
                add = false;
                if (this.deepEqual(json, existingItem)) {
                    console.log("Objects are the same:" + json + " existing json:" + list[json.name])
                    return;
                }
                json.sparklineData = existingItem.sparklineData;
                json.sparkline = existingItem.sparkline;
            }

            json=model.updateMidPrice(json);
            list.push(json);
            // list[json.name] = json;

            currency.notifyObservers(json, add);
        },
        /**
        */
        remove: function(index) {
            // list.splice(index, 1);
            // currency.notifyObservers();
        },
        // observer
        register: function(...args) {
            currency.removeAll();
            // args.forEach(elem => {
            //     currency.add(elem);
            // });
            currency.add(args[0]);

        }
    };
}
