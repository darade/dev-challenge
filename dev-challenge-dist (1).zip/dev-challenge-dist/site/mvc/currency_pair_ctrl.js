
function CurrencyPairCtrl(view, model) {
    const DOM = view.getDOM();
    model.register(view, this);
    return {
        notify: function() {
            const that = this;
        },
        startReciveingMessage:function(client){
          var subscription = client.subscribe("/fx/prices", function(message){
            if (message.body) {
                //console.info("got message with body " + message.body)
                model.add(message.body);
               } else {
                console.info("got empty message");
               }
          });
        }
    }
}
